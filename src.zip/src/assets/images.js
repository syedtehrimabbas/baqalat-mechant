export const images = {
    splashBG: require("../assets/images/splash/splash_bg.png"),
    appIcon: require("../assets/images/logo/full_white_logo.png"),
    welcome: require("../assets/images/welcome/welcome.png"),
    fruitBG: require("./images/fruit/fruit_with_bg.png"),
    login_icon: require("./images/icons/ic_login.png"),
    signup_icon: require("./images/icons/ic_person.png"),
    email: require("./images/icons/icon_email.png"),
    lock: require("./images/icons/icon_lock.png"),
    signup_tick: require("./images/icons/signup__success_logo.png"),
    deliveryAddress: require("./images/location/imgdelivery_address/delivery_address.png"),
    searchIcon: require("../assets/images/ic_search.png"),
    plusIcon: require("../assets/images/ic_plus.png"),
    backArrow: require("../assets/images/arrow_back.png")
};