const AppName = "Baqalat";
const PreferencesKeys = {
    USER: AppName + '_USER',
};
export default PreferencesKeys