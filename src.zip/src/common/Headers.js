import React from 'react';
import {Image, StyleSheet, Text, TouchableWithoutFeedback, View} from 'react-native';
import AppCardView from '../components/AppCardView'
import colors from "../theme/colors";
import {Typography} from "../theme/Typography";
import {AppStyles} from "../theme/styles";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import {heightPercentageToDP as hp, widthPercentageToDP as wp} from 'react-native-responsive-screen';


export const Header = ({icon}) => {
    return (
        <View style={styles.containerStyle}>
            <Image
                style={{width: 100, height: hp(18), tintColor: 'white', resizeMode: 'contain'}}
                source={icon}/>
        </View>
    );
};

export const PropertyHeader = ({icon, righChild}) => {
    return (
        <View style={styles.containerStyle}>
            <View style={{alignSelf: 'center', right: 10, position: 'absolute'}}>
                {righChild}
            </View>
        </View>
    );
};

export const BackButtonHeader = ({nav, title}) => {
    return <AppCardView
        style={{
            width: '100%',
            height: 50,
            justifyContent: 'center',
            backgroundColor: colors.primaryColor
        }}
        cornerRadius={0}
        cardElevation={5}
        children={
            <View style-={AppStyles.rowContainer}>
                <TouchableWithoutFeedback onPress={() => {
                    nav.goBack()
                }}>
                    <FontAwesome5 name="arrow-left" color={colors.white}
                                  style={{marginStart: 10, alignSelf: 'flex-start'}} size={20}/>

                </TouchableWithoutFeedback>

                <Text style={[Typography.Bold, {
                    marginTop: -18,
                    alignSelf: 'center',
                    color: colors.white,
                    fontSize: 15
                }]}>
                    {title}
                </Text>
            </View>

        }
    />
};

const styles = StyleSheet.create({
    containerStyle: {
        height: hp(8),
        width: wp(100),
        backgroundColor: colors.primaryColor,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    }
});
