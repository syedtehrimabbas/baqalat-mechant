export const WELCOME = "Welcome";
export const SETUP_LOCATION = "SetupLocation";
export const LOGIN = "Login";
export const SIGNUP = "Signup";
export const CARS_SCREEN = "CarsScreen";
export const ALL_CARS_SCREEN = "AllCarsScreen";
export const BIKES_SCREEN = "BikesScreen";
export const ALL_BIKES_SCREEN = "AllBikesScreen";
export const MORE_SCREEN = "MoreScreen";
export const PROPERTY_SCREEN = "PropertyScreen";
export const HOME = "Home";
export const CAR_DETAILS = "CardDetails";
export const BIKE_DETAILS = "BikeDetails";
export const SELL_CAR = "SellCarScreen";
export const SELL_BIKE = "SellBikeScreen";
export const PROPERTY_DETAILS = "PropertyDetails";

class ScreenNames {

}