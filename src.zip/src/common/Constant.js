export const Constant = {
    appName: "Bargain PK",
    searchCar: "Search your dream car",
    searchBike: "Search your dream bike",
    searchProperty: "Search property for sale",
    searchPropertyRent: "Search property for rent",
    saleCar: "Sell your car",
    saleBike: "Sell your bike",
    saleProperty: "Sell your Property",
    rentProperty: "Ret out your Property",
    featuredAds: "Featured ADS",
    managedByApp: "Managed by ",
    viewAll: "View All",
};